﻿param
(
    [Parameter(Mandatory = $true)]
    [String]$domainName,

    [Parameter(Mandatory = $true)]
    [System.Management.Automation.PSCredential]
    $admincreds
)

# Global variables
$domainFirstName = ($domainName.Split('.'))[0]
$sqlserverFQDN = ("SQL." + $domainName)
$sqlInstanceName = ($sqlserverFQDN + "\MSSQLSERVER")

# Logins to create
$adminUser = ($domainFirstName + "\" + $admincreds.UserName)
[System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("$domainFirstName\$($Admincreds.UserName)", $Admincreds.Password)

$sqlsvc = ($domainFirstName + "\" + "sqlsvc")
[System.Management.Automation.PSCredential]$sqlsvcSqlLoginCreds = New-Object System.Management.Automation.PSCredential ($sqlsvc, $sqlsvcSqlLoginPassword)

$spfarmsvc = ($domainFirstName + "\" + "spfarmsvc")
[System.Management.Automation.PSCredential]$spfarmsvcSqlLoginCreds = New-Object System.Management.Automation.PSCredential ($spfarmsvc, $spfarmsvcSqlLoginPassword)

$configData= @{
    AllNodes = @(
        @{
            NodeName = "localhost"
            PsDscAllowPlainTextPassword = $true
            PsDscAllowDomainUser = $true
        }
    )
}

Configuration SQLConfig
{
    Import-DSCResource -ModuleName SQLServerDSC, xNetworking, PSDesiredStateConfiguration
    
    Node $AllNodes.NodeName
    {
        # Open port 1433
        xFireWall SQLFirewallRule
        {
            Name = "AllowSQLConnection"
            DisplayName = 'Allow SQL Connection'
            Group = 'DSC Configuration Rules'
            Ensure = 'Present'
            Enabled = 'True'
            Profile = ('Domain')
            Direction = 'InBound'
            LocalPort = ('1433')
            Protocol = 'TCP'
            Description = 'Firewall Rule to allow SQL communication'
        }

        # If SQL login mode is Integrated (1), set to Mixed (2)
        Script ChangeSqlAuth
        {
            DependsOn = "[xFirewall]SQLFirewallRule"

            GetScript = {
                $authMode = Get-ItemProperty -path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQLSERVER' -name "LoginMode"
                Return @{            
                    Result = [string]$($authMode.LoginMode)            
                }
            }

            TestScript = {
                $authMode = Get-ItemProperty -path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQLSERVER' -name "LoginMode"
                if ($authMode.LoginMode -eq 1) {
                Return $false
                }
                else {
                Return $true
                }
            }

            SetScript = {
            # Set LoginMode value to 2
            $modePath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQLSERVER"
            $modeName = "LoginMode"
            $modeValue = "2"
            New-ItemProperty -Path $modePath -Name $modeName -Value $modeValue -PropertyType DWORD -Force | Out-Null
            # Restart SQL service
            Get-Service -Name MSSQLSERVER | Restart-Service
            (Get-Service -Name MSSQLSERVER).WaitForStatus('Running')
            Write-Output "SQL service is running."
            }
        }
        
        # Add SQL logins and add to sysadmin role
        Script AddSqlLogins
        {
            DependsOn = "[Script]ChangeSqlAuth"

            GetScript = {
                Add-Type -AssemblyName "Microsoft.SqlServer.ConnectionInfo, Version=12.0.0.0,  Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop
                Add-Type -AssemblyName "Microsoft.SqlServer.Smo, Version=12.0.0.0,Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop
                Add-Type -AssemblyName "Microsoft.SqlServer.SMOExtended, Version=12.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop
                Add-Type -AssemblyName "Microsoft.SqlServer.SqlEnum, Version=12.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop
                Add-Type -AssemblyName "Microsoft.SqlServer.Management.Sdk.Sfc, Version=12.0.0.0,Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop
                # Check for existing logins
                $sqlSrv = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $sqlInstanceName
                $logins = $sqlSrv.Logins | Where {$_.Name -eq $adminUser -or $_.Name -eq $sqlsvc -or $_.Name -eq $spfarmsvc}
            }

            TestScript = {
                Add-Type -AssemblyName "Microsoft.SqlServer.ConnectionInfo, Version=12.0.0.0,  Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop
                Add-Type -AssemblyName "Microsoft.SqlServer.Smo, Version=12.0.0.0,Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop
                Add-Type -AssemblyName "Microsoft.SqlServer.SMOExtended, Version=12.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop
                Add-Type -AssemblyName "Microsoft.SqlServer.SqlEnum, Version=12.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop
                Add-Type -AssemblyName "Microsoft.SqlServer.Management.Sdk.Sfc, Version=12.0.0.0,Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop
                
                $sqlSrv = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $sqlInstanceName
                $logins = $sqlSrv.Logins | Where {$_.Name -eq $adminUser -or $_.Name -eq $sqlsvc -or $_.Name -eq $spfarmsvc}
                if (!$logins) {
                Return $false
                }
                else {
                Return $true
                }
            }

            SetScript = {
                Add-Type -AssemblyName "Microsoft.SqlServer.ConnectionInfo, Version=12.0.0.0,  Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop
                Add-Type -AssemblyName "Microsoft.SqlServer.Smo, Version=12.0.0.0,Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop
                Add-Type -AssemblyName "Microsoft.SqlServer.SMOExtended, Version=12.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop
                Add-Type -AssemblyName "Microsoft.SqlServer.SqlEnum, Version=12.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop
                Add-Type -AssemblyName "Microsoft.SqlServer.Management.Sdk.Sfc, Version=12.0.0.0,Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop

                $sqlSrv = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $sqlInstanceName

                $logins1 = $sqlSrv.Logins | ? {$_.Name -eq $adminUser}
                if (!$logins1) {
                    # Create login for admin account
                    Write-Output "Creating login for " $adminUser
                    $login1 = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Login -ArgumentList $sqlSrv, $adminUser
                    $login1.LoginType = "WindowsUser"
                    $login1.Create()
                    $login1.AddToRole("sysadmin")
                    $login1.Alter()
                    }

                $logins2 = $sqlSrv.Logins | ? {$_.Name -eq $sqlsvc}
                if (!$logins2) {
                    # Create login for sqlsvc account
                    Write-Output "Creating login for " $sqlsvc
                    $login2 = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Login -ArgumentList $sqlSrv, $sqlsvc
                    $login2.LoginType = "WindowsUser"
                    $login2.Create()
                    $login2.AddToRole("sysadmin")
                    $login2.Alter()
                    }

                $logins3 = $sqlSrv.Logins | ? {$_.Name -eq $spfarmsvc}
                if (!$logins3) {
                    # Create login for spfarmsvc account
                    Write-Output "Creating login for " $spfarmsvc
                    $login3 = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Login -ArgumentList $sqlSrv, $spfarmsvc
                    $login3.LoginType = "WindowsUser"
                    $login3.Create()
                    $login3.AddToRole("sysadmin")
                    $login3.Alter()
                }
            }
        }
    }
}