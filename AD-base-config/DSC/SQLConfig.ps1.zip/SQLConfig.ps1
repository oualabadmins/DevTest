﻿Configuration SQLConfig
{
    Import-DSCResource -ModuleName xNetworking

    Node $ParamMachineName
    {
        xFireWall SQLFirewallRule
        {
            Name = "AllowSQLConnection"
            DisplayName = 'Allow SQL Connection'
            Group = 'DSC Configuration Rules'
            Ensure = 'Present'
            Enabled = 'True'
            Profile = ('Domain')
            Direction = 'InBound'
            LocalPort = ('1433')
            Protocol = 'TCP'
            Description = 'Firewall Rule to allow SQL communication'
        }
    }
}