﻿Configuration SQLConfig
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]
        $Admincreds
    )

    Import-DSCResource -ModuleName SQLServerDSC

    $domainFirstName = ($domainName.Split('.'))[0]

    # Create domain admin creds
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    
    # Add sqlsvc, spsvc and admin account to sysadmin role
    Node $ParamMachineName
    {
        SqlServerRole Add_ServerRole
        {
            Ensure               = 'Present'
            ServerRoleName       = 'sysadmin'
            Members              = "$domainFirstName\sqlsvc", "$domainFirstName\spsvc", "$domainFirstName\$AdminCreds.UserName"
            ServerName           = "sql.$domainName"
            InstanceName         = 'MSSQLSERVER'
            PsDscRunAsCredential = $DomainCreds
        }
    }
}