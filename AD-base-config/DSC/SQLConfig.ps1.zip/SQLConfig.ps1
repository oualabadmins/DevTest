﻿param
(
    [Parameter(Mandatory = $true)]
    [String]$domainName,

    [Parameter(Mandatory = $true)]
    [System.Management.Automation.PSCredential]
    $admincreds
)

# Global variables
$domainFirstName = ($domainName.Split('.'))[0]
$sqlserverFQDN = ("SQL." + $domainName)
$sqlInstanceName = ($sqlserverFQDN + "\MSSQLSERVER")
$domainAdmin = ($domainFirstName + '\' + $admincreds.UserName)

$configData= @{
    AllNodes = @(
        @{
            NodeName = "localhost"
            PsDscAllowPlainTextPassword = $true
            PsDscAllowDomainUser = $true
        }
    )
}

Configuration SQLConfig
{
    Import-DSCResource -ModuleName SQLServerDSC, xNetworking
    
    Node $AllNodes.NodeName
    {
        # Open port 1433
        xFireWall SQLFirewallRule
        {
            Name = "AllowSQLConnection"
            DisplayName = 'Allow SQL Connection'
            Group = 'DSC Configuration Rules'
            Ensure = 'Present'
            Enabled = 'True'
            Profile = ('Domain')
            Direction = 'InBound'
            LocalPort = ('1433')
            Protocol = 'TCP'
            Description = 'Firewall Rule to allow SQL communication'
        }

        # Create SQL login for domain admin account
        SqlServerLogin CreateLogin1
        {
            Ensure               = 'Present'
            Name                 = $domainAdmin
            LoginType            = 'WindowsUser'
            ServerName           = $sqlserverFQDN
            InstanceName         = 'MSSQLSERVER'
            PsDscRunAsCredential = $admincreds
        }
        
        # Create SQL login sqlsvc
        SqlServerLogin CreateLogin1
        {
            Ensure               = 'Present'
            Name                 = "$domainFirstName\sqlsvc"
            LoginType            = 'WindowsUser'
            ServerName           = $sqlserverFQDN
            InstanceName         = 'MSSQLSERVER'
            PsDscRunAsCredential = $admincreds
        }
        
        # Create SQL login spfarmsvc
        SqlServerLogin CreateLogin1
        {
            Ensure               = 'Present'
            Name                 = "$domainFirstName\spfarmsvc"
            LoginType            = 'WindowsUser'
            ServerName           = $sqlserverFQDN
            InstanceName         = 'MSSQLSERVER'
            PsDscRunAsCredential = $admincreds
        }
        
        SqlServerRole Add_ServerRole_AdminSqlforBI
        {
            Ensure               = 'Present'
            ServerRoleName       = 'sysadmin'
            MembersToInclude     = $domainAdmin, "$domainFirstName\sqlsvc", "$domainFirstName\spfarmsvc"
            ServerName           = $sqlserverFQDN
            InstanceName         = 'MSSQLSERVER'
            PsDscRunAsCredential = $admincreds
        }
    }
}