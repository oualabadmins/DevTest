﻿Configuration SQLConfig
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]
        $Admincreds
    )

    Import-DSCResource -ModuleName SQLServerDSC, xNetworking

    $domainFirstName = ($domainName.Split('.'))[0]
    $sqlUserName = ($Admincreds.UserName).Split('\')[1]

    # Create local sql admin creds
    [System.Management.Automation.PSCredential ]$sqlCreds = New-Object System.Management.Automation.PSCredential ("sql\$sqlUserName", $Admincreds.Password)
    
    Node localhost
    {
        # Add sqlsvc, spfarmsvc and admin account to sysadmin role
        SqlServerRole Add_ServerRole
        {
            Ensure               = 'Present'
            ServerRoleName       = 'sysadmin'
            Members              = "$domainFirstName\sqlsvc", "$domainFirstName\spfarmsvc", "$domainFirstName\$AdminCreds.UserName"
            ServerName           = "sql.$domainName"
            InstanceName         = 'MSSQLSERVER'
            PsDscRunAsCredential = $sqlCreds
        }

        # Open port 1433
        xFireWall SQLFirewallRule
        {
            Name = "AllowSQLConnection"
            DisplayName = 'Allow SQL Connection'
            Group = 'DSC Configuration Rules'
            Ensure = 'Present'
            Enabled = 'True'
            Profile = ('Domain')
            Direction = 'InBound'
            LocalPort = ('1433')
            Protocol = 'TCP'
            Description = 'Firewall Rule to allow SQL communication'
        }
    }
}