﻿Configuration SQLConfig
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]
        $Admincreds
    )

    Import-DSCResource -ModuleName SQLServerDSC

    $domainFirstName = ($domainName.Split('.'))[0]

    # Create local sql admin creds
    [System.Management.Automation.PSCredential ]$sqlCreds = New-Object System.Management.Automation.PSCredential ("sql\$($Admincreds.UserName)", $Admincreds.Password)
    
    Node localhost
    {
        # Add sqlsvc, spfarmsvc and admin account to sysadmin role
        SqlServerRole Add_ServerRole
        {
            Ensure               = 'Present'
            ServerRoleName       = 'sysadmin'
            Members              = "$domainFirstName\sqlsvc", "$domainFirstName\spfarmsvc", "$domainFirstName\$AdminCreds.UserName"
            ServerName           = "sql.$domainName"
            InstanceName         = 'MSSQLSERVER'
            PsDscRunAsCredential = $sqlCreds
        }
    }
}