﻿<#
    .SQLConfig
    This configuration configures SQL Server with a firewall rule to permit traffic on port 1433, and to add logins 
    and add them to the sysadmin role. It also executes the BaseConfig script.

    kvice 7/11/2018
    5/8/2019  - Added OU "Machines" to mitigate error joining domain to default OU, changed DNS forwarder to 10.50.10.50
    5/23/2019 - Added BaseConfig script
#>

$configData= @{
    AllNodes = @(
        @{
            NodeName = "localhost"
            PsDscAllowPlainTextPassword = $true
            PsDscAllowDomainUser = $true
        }
    )
}

Configuration SQLConfig
{
    param
    (
        [Parameter(Mandatory = $true)]
        [String]$domainName,

        [Parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]
        $admincreds
    )

    # Import DSC modules
    Import-DSCResource -ModuleName SQLServerDSC, xNetworking

    # Global variables
    $domainFirstName = ($domainName.Split('.'))[0]
    $sqlserverFQDN = ("SQL." + $domainName)
    $sqlInstanceName = ($sqlserverFQDN + "\MSSQLSERVER")
    $domainAdmin = ($domainFirstName + '\' + $admincreds.UserName)
    
    Node $AllNodes.NodeName
    {
        # Open port 1433
        xFireWall SQLFirewallRule
        {
            Name = "AllowSQLConnection"
            DisplayName = 'Allow SQL Connection'
            Group = 'DSC Configuration Rules'
            Ensure = 'Present'
            Enabled = 'True'
            Profile = ('Domain')
            Direction = 'InBound'
            LocalPort = ('1433')
            Protocol = 'TCP'
            Description = 'Firewall Rule to allow SQL communication'
        }

        # Create SQL login for domain admin account
        SqlServerLogin CreateLogin1
        {
            Ensure               = 'Present'
            Name                 = $domainAdmin
            LoginType            = 'WindowsUser'
            ServerName           = $sqlserverFQDN
            InstanceName         = 'MSSQLSERVER'
            PsDscRunAsCredential = $admincreds
        }
        
        # Create SQL login sqlsvc
        SqlServerLogin CreateLogin1
        {
            Ensure               = 'Present'
            Name                 = "$domainFirstName\sqlsvc"
            LoginType            = 'WindowsUser'
            ServerName           = $sqlserverFQDN
            InstanceName         = 'MSSQLSERVER'
            PsDscRunAsCredential = $admincreds
        }
        
        # Create SQL login spfarmsvc
        SqlServerLogin CreateLogin1
        {
            Ensure               = 'Present'
            Name                 = "$domainFirstName\spfarmsvc"
            LoginType            = 'WindowsUser'
            ServerName           = $sqlserverFQDN
            InstanceName         = 'MSSQLSERVER'
            PsDscRunAsCredential = $admincreds
        }
        
        SqlServerRole Add_ServerRole_AdminSqlforBI
        {
            Ensure               = 'Present'
            ServerRoleName       = 'sysadmin'
            MembersToInclude     = $domainAdmin, "$domainFirstName\sqlsvc", "$domainFirstName\spfarmsvc"
            ServerName           = $sqlserverFQDN
            InstanceName         = 'MSSQLSERVER'
            PsDscRunAsCredential = $admincreds
        }
        
	    Script BaseConfig
        {
            SetScript =
            {

            # Disable UserAccessControl
	        Write-Host
	        Write-Host "Configuring " -NoNewline; Write-Host "UAC" -f Cyan -NoNewline; Write-Host "..."
	        Set-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "ConsentPromptBehaviorAdmin" -Value 00000000
	        Write-Host "Done." -f Green

	        # Install .NET 3.5
	        Add-WindowsFeature NET-Framework-Core

	        # Disable IE ESC
	        $AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
	        $UserKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
	        Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value 0
	        Set-ItemProperty -Path $UserKey -Name "IsInstalled" -Value 0

	        # Disable Server Manager at startup
	        Disable-ScheduledTask -TaskPath "\Microsoft\Windows\Server Manager\" -TaskName "ServerManager"
	
	        # Set power management plan to High Performance
	        Start-Process -FilePath "$env:SystemRoot\system32\powercfg.exe" -ArgumentList "/s 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c" -NoNewWindow
	
	        # Disable warning on file open
	        Push-Location
	        Set-Location HKCU:
	        #Test-Path .\Software\Microsoft\Windows\CurrentVersion\Policies\Associations
	        New-Item -Path .\Software\Microsoft\Windows\CurrentVersion\Policies -Name Associations
	        Pop-Location
	        New-ItemProperty -name LowRiskFileTypes -propertyType string HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Associations -value ".exe;.bat;.msi;.reg;.ps1;.vbs"

            # Configure Explorer (show file extensions, hidden items, replace cmd with PS in Start)
            $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
            $path1 = Test-Path $key -ErrorAction SilentlyContinue
            if ($path1 -eq $true) {
	        Set-ItemProperty $key Hidden 1
	        Set-ItemProperty $key HideFileExt 0
	        Set-ItemProperty $key ShowSuperHidden 1
	        Set-ItemProperty $key DontUserPowerShellOnWinx 0
            Stop-Process -processname explorer
            }
	
	        # Set WUSA to auto-install updates
	        $wusa = (New-Object -ComObject "Microsoft.Update.AutoUpdate").Settings
	        $wusa.NotificationLevel = 4
	        $wusa.ScheduledInstallationDay = 0
	        $wusa.IncludeRecommendedUpdates = $true
	        $wusa.NonAdministratorsElevated = $true
	        $wusa.FeaturedUpdatesEnabled = $true
	        $wusa.save()

	        # Set time zone to PST
	        tzutil /s "Pacific Standard Time"

	        # Create C:\Scripts
            New-Item -Path C:\Scripts -ItemType Directory -ErrorAction SilentlyContinue
            
            }
            GetScript =  { @{} }
            TestScript = { $false }
        }
    }
}