﻿<#
    .AppConfig
    This configuration:
    * Provisions IIS, .NET 4.5 and management tools.
    * Creates C:\Files, adds example.txt and shares directory with RWX perms for <domain>\User1.
    * Executes the BaseConfig script.

    kvice 7/13/2018

    7/17/2018 - Updated modules to import
    5/23/2019 - Added BaseConfig script
#>

$configData= @{
    AllNodes = @(
        @{
            NodeName = "localhost"
            PsDscAllowPlainTextPassword = $true
            PsDscAllowDomainUser = $true
        }
    )
}

configuration AppConfig
{
    param
   (
        [Parameter(Mandatory)]
        [String]$DomainName
    )

    # Import DSC modules
    Import-DscResource -Module PSDesiredStateConfiguration, xSmbShare, cNtfsAccessControl
    
    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }     

    # Install IIS role 
    WindowsFeature IIS 
    { 
        Ensure  = “Present” 
        Name    = “Web-Server” 
    } 
 
    # Install ASP .NET 4.5 role 
    WindowsFeature AspNet45 
    { 
        Ensure  = “Present” 
        Name    = “Web-Asp-Net45” 
    }
    
    # Install IIS management tools       
    WindowsFeature IISManagementTools {
 
        Name = 'Web-Mgmt-Tools'
        Ensure = 'Present'
        DependsOn = '[WindowsFeature]IIS'
    }

    # Create folder
    File NewFolder {
            Type = 'Directory'
            DestinationPath = 'C:\Files'
            Ensure = "Present"
        }

    # Create file
    File AddFile {
            DestinationPath = 'C:\Files\example.txt'
            Ensure = "Present"
            Contents = ''
        }

    # Share folder
    xSmbShare ShareFolder {
            Ensure = 'Present'
            Name   = 'Files'
            Path = 'C:\Files'
            FullAccess = 'Everyone'
            DependsOn = '[File]NewFolder'
        }

    # Set NTFS perms
    cNtfsPermissionEntry 'FilePermissionChange' {
            Ensure = 'Present'
            DependsOn = "[File]NewFolder"
            Principal = "$DomainName\User1"
            Path = 'C:\Files'
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'FullControl'
                    Inheritance = 'ThisFolderSubfoldersAndFiles'
                    NoPropagateInherit = $false
                }
            )
        }
        
	    Script BaseConfig
        {
            SetScript =
            {

            # Disable UserAccessControl
	        Write-Host
	        Write-Host "Configuring " -NoNewline; Write-Host "UAC" -f Cyan -NoNewline; Write-Host "..."
	        Set-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "ConsentPromptBehaviorAdmin" -Value 00000000
	        Write-Host "Done." -f Green

	        # Install .NET 3.5
	        Add-WindowsFeature NET-Framework-Core

	        # Disable IE ESC
	        $AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
	        $UserKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
	        Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value 0
	        Set-ItemProperty -Path $UserKey -Name "IsInstalled" -Value 0

	        # Disable Server Manager at startup
	        Disable-ScheduledTask -TaskPath "\Microsoft\Windows\Server Manager\" -TaskName "ServerManager"
	
	        # Set power management plan to High Performance
	        Start-Process -FilePath "$env:SystemRoot\system32\powercfg.exe" -ArgumentList "/s 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c" -NoNewWindow
	
	        # Disable warning on file open
	        Push-Location
	        Set-Location HKCU:
	        #Test-Path .\Software\Microsoft\Windows\CurrentVersion\Policies\Associations
	        New-Item -Path .\Software\Microsoft\Windows\CurrentVersion\Policies -Name Associations
	        Pop-Location
	        New-ItemProperty -name LowRiskFileTypes -propertyType string HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Associations -value ".exe;.bat;.msi;.reg;.ps1;.vbs"

            # Configure Explorer (show file extensions, hidden items, replace cmd with PS in Start)
            $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
            $path1 = Test-Path $key -ErrorAction SilentlyContinue
            if ($path1 -eq $true) {
	        Set-ItemProperty $key Hidden 1
	        Set-ItemProperty $key HideFileExt 0
	        Set-ItemProperty $key ShowSuperHidden 1
	        Set-ItemProperty $key DontUserPowerShellOnWinx 0
            Stop-Process -processname explorer
            }
	
	        # Set WUSA to auto-install updates
	        $wusa = (New-Object -ComObject "Microsoft.Update.AutoUpdate").Settings
	        $wusa.NotificationLevel = 4
	        $wusa.ScheduledInstallationDay = 0
	        $wusa.IncludeRecommendedUpdates = $true
	        $wusa.NonAdministratorsElevated = $true
	        $wusa.FeaturedUpdatesEnabled = $true
	        $wusa.save()

	        # Set time zone to PST
	        tzutil /s "Pacific Standard Time"

	        # Create C:\Scripts
            New-Item -Path C:\Scripts -ItemType Directory -ErrorAction SilentlyContinue
            
            }
            GetScript =  { @{} }
            TestScript = { $false }
        }
    }
}