For more information about SharePointDsc and all of the resources,
including details and examples, please check out our
[Wiki](https://github.com/PowerShell/SharePointDsc/wiki)
