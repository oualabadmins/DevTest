# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource is used to configure a group within Project Server. This is only
available for use when the site is configured to use Project Server permissions
mode and for Project Server 2016 only.
